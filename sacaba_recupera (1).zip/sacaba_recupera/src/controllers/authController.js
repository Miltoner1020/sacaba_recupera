const UsuarioModel = require('../models/usuarioModel');
const bcrypt = require('bcryptjs');

class AuthController {
    // Muestra la pantalla de login
    static renderLogin(req, res) {
        res.render('auth/login', { error: null });
    }

    // Procesa el formulario cuando el usuario intenta entrar
    static async login(req, res) {
        const { email, password } = req.body; // Sacamos los datos que envió el formulario
        try {
            // 1. Buscamos si existe el correo en la BD
            const user = await UsuarioModel.buscarPorEmail(email);
            if (!user) {
                return res.render('auth/login', { error: 'Credenciales inválidas.' });
            }

            // 2. Comparamos la contraseña escrita con el hash encriptado de la BD
            const match = await bcrypt.compare(password, user.password);
            if (!match) {
                return res.render('auth/login', { error: 'Credenciales inválidas.' });
            }

            // 3. Si todo coincide, guardamos sus datos básicos en la sesión del servidor
            req.session.user = {
                id: user.id,
                nombre: user.nombre,
                rol: user.rol
            };
            res.redirect('/reportes'); // Lo mandamos al inicio
        } catch (error) {
            res.render('auth/login', { error: 'Error interno del servidor.' });
        }
    }

    // Muestra la pantalla de registro
    static renderRegister(req, res) {
        res.render('auth/register', { error: null });
    }

    // Procesa el registro de un usuario nuevo
    static async register(req, res) {
        const { nombre, email, telefono, password, rol } = req.body;
        try {
            // Verificamos que el correo no esté repetido
            const existe = await UsuarioModel.buscarPorEmail(email);
            if (existe) {
                return res.render('auth/register', { error: 'El correo electrónico ya está registrado.' });
            }

            // Mandamos a guardar al Modelo y redirigimos al login
            await UsuarioModel.registrar(nombre, email, telefono, password, rol);
            res.redirect('/auth/login');
        } catch (error) {
            res.render('auth/register', { error: 'Error al registrar usuario.' });
        }
    }

    // Cierra sesión borrando la cookie del servidor
    static logout(req, res) {
        req.session.destroy(() => {
            res.redirect('/auth/login');
        });
    }
}

module.exports = AuthController;