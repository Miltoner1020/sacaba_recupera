const ReporteModel = require('../models/reporteModel');

class ReporteController {
    // Carga el muro principal con todos los reportes (y filtros si los hay)
    static async index(req, res) {
        // req.query lee los parámetros de la URL (ej: ?categoria=celular&buscar=samsung)
        const { categoria = '', buscar = '' } = req.query;
        try {
            const reportes = await ReporteModel.listar(categoria, buscar);
            // Renderizamos la vista index.ejs pasándole los reportes encontrados y lo que buscó
            res.render('reportes/index', { reportes, query: { categoria, buscar } });
        } catch (error) {
            res.status(500).send('Error al listar reportes');
        }
    }

    // Muestra el formulario para publicar pérdida o hallazgo
    static renderCrear(req, res) {
        // Protección de ruta: si no está logueado, no puede publicar, lo mandamos al login
        if (!req.session.user) {
            return res.redirect('/auth/login');
        }
        res.render('reportes/crear');
    }

    // Guarda el reporte en la base de datos
    static async crear(req, res) {
        if (!req.session.user) {
            return res.redirect('/auth/login');
        }

        const { tipo, titulo, categoria, descripcion, lugar_ruta, fecha_evento } = req.body;
        // Si subió una foto, Multer ya la guardó y nos deja el nombre en req.file.filename
        const imagen = req.file ? req.file.filename : null;

        try {
            await ReporteModel.guardar(
                req.session.user.id, // Sacamos el ID del usuario directamente de su sesión activa
                tipo,
                titulo,
                categoria,
                descripcion,
                lugar_ruta,
                fecha_evento,
                imagen
            );
            res.redirect('/reportes'); // Volvemos al muro para ver la publicación
        } catch (error) {
            res.status(500).send('Error al guardar el reporte');
        }
    }

    // Cambia el estado del objeto (solo permitido para el administrador)
    static async cambiarEstado(req, res) {
        // Verificamos que tenga sesión y que su rol sea 'admin'
        if (!req.session.user || req.session.user.rol !== 'admin') {
            return res.status(403).send('No autorizado');
        }

        const { id, estado } = req.body;
        try {
            await ReporteModel.cambiarEstado(id, estado);
            res.redirect('/reportes');
        } catch (error) {
            res.status(500).send('Error al actualizar estado');
        }
    }
}

module.exports = ReporteController;