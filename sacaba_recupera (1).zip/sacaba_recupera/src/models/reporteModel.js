const db = require('../config/database');

class ReporteModel {
    // Trae todos los reportes y aplica filtros si el usuario escribió algo en el buscador
    static async listar(categoria = '', buscar = '') {
        // Hacemos JOIN con usuarios para traer también el nombre y teléfono del que publicó el reporte
        // El "WHERE 1=1" es un truco para poder concatenar "AND ..." fácilmente después
        let sql = `SELECT r.*, u.nombre AS autor, u.telefono 
                   FROM reportes r 
                   JOIN usuarios u ON r.usuario_id = u.id 
                   WHERE 1=1`;
        const params = [];

        // Si eligió una categoría en el select, agregamos esa condición
        if (categoria) {
            sql += ' AND r.categoria = ?';
            params.push(categoria);
        }
        // Si escribió algo en la barra de búsqueda, buscamos coincidencias en el título o en el lugar/ruta
        if (buscar) {
            sql += ' AND (r.titulo LIKE ? OR r.lugar_ruta LIKE ?)';
            params.push(`%${buscar}%`, `%${buscar}%`); // Los % sirven para buscar texto parcial
        }

        // Ordenamos para que los reportes más nuevos salgan primero
        sql += ' ORDER BY r.creado_en DESC';
        
        const [rows] = await db.execute(sql, params);
        return rows; // Devuelve la lista de reportes
    }

    // Guarda un nuevo reporte de pérdida o hallazgo
    static async guardar(usuario_id, tipo, titulo, categoria, descripcion, lugar_ruta, fecha_evento, imagen) {
        // Si reporta pérdida el estado inicial es 'perdido', si reporta hallazgo es 'encontrado'
        const estado = tipo === 'perdida' ? 'perdido' : 'encontrado';
        
        const sql = `INSERT INTO reportes (usuario_id, tipo, titulo, categoria, descripcion, lugar_ruta, fecha_evento, imagen, estado) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        const [result] = await db.execute(sql, [usuario_id, tipo, titulo, categoria, descripcion, lugar_ruta, fecha_evento, imagen, estado]);
        
        return result.insertId;
    }

    // Actualiza el estado (perdido, encontrado, en_verificacion, devuelto) - Solo lo usa el admin
    static async cambiarEstado(id, nuevoEstado) {
        const sql = 'UPDATE reportes SET estado = ? WHERE id = ?';
        const [result] = await db.execute(sql, [nuevoEstado, id]);
        
        return result.affectedRows > 0; // Devuelve true si se actualizó alguna fila
    }
}

module.exports = ReporteModel;