const db = require('../config/database');
const bcrypt = require('bcryptjs'); // Librería para encriptar contraseñas (cumple RNF-02)

class UsuarioModel {
    // Función para guardar un usuario nuevo en la BD
    static async registrar(nombre, email, telefono, password, rol = 'ciudadano') {
        // Encriptamos la contraseña antes de guardarla (el 10 es el nivel de seguridad/salt)
        const hash = await bcrypt.hash(password, 10);
        
        // Usamos signos de interrogación (?) para evitar inyección SQL
        const sql = 'INSERT INTO usuarios (nombre, email, telefono, password, rol) VALUES (?, ?, ?, ?, ?)';
        const [result] = await db.execute(sql, [nombre, email, telefono, hash, rol]);
        
        return result.insertId; // Devuelve el ID del usuario recién creado
    }

    // Busca un usuario por su correo (sirve tanto para el login como para ver si ya existe al registrarse)
    static async buscarPorEmail(email) {
        const sql = 'SELECT * FROM usuarios WHERE email = ? LIMIT 1';
        const [rows] = await db.execute(sql, [email]);
        
        return rows[0] || null; // Si encuentra devuelve el objeto usuario, si no devuelve null
    }
}

module.exports = UsuarioModel;