// Usamos mysql2/promise para poder hacer consultas modernas con async/await
const mysql = require('mysql2/promise');
require('dotenv').config();

// Creamos un "pool" de conexiones (es mejor que una sola conexión porque reutiliza canales y evita que se cuelgue)
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost', // Nuestro servidor local (XAMPP)
    user: process.env.DB_USER || 'root',      // Usuario por defecto de XAMPP
    password: process.env.DB_PASSWORD || '',  // En XAMPP viene vacío por defecto
    database: process.env.DB_NAME || 'sacaba_recupera_db', // Nuestra base de datos
    waitForConnections: true,
    connectionLimit: 10, // Máximo 10 consultas simultáneas
    queueLimit: 0
});

// Exportamos la conexión para usarla en los Modelos
module.exports = pool;