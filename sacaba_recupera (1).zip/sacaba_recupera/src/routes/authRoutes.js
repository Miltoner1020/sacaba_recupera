const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/authController');

// Rutas GET: muestran las pantallas (formularios)
// Rutas POST: reciben los datos cuando se envía el formulario
router.get('/login', AuthController.renderLogin);
router.post('/login', AuthController.login);

router.get('/register', AuthController.renderRegister);
router.post('/register', AuthController.register);

router.get('/logout', AuthController.logout);

module.exports = router;