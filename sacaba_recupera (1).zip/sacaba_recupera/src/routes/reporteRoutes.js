const express = require('express');
const router = express.Router();
const multer = require('multer'); // Librería para recibir archivos/imágenes en formularios
const path = require('path');
const ReporteController = require('../controllers/reporteController');

// Configuramos dónde y con qué nombre se guardarán las fotos subidas
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        // Carpeta destino: public/uploads
        cb(null, path.join(__dirname, '../../public/uploads'));
    },
    filename: (req, file, cb) => {
        // Le ponemos la fecha en milisegundos + número aleatorio para que no se sobreescriban fotos con el mismo nombre
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname)); // Conserva .jpg, .png, etc.
    }
});
const upload = multer({ storage });

// Definición de endpoints de reportes
router.get('/', ReporteController.index);
router.get('/crear', ReporteController.renderCrear);
// upload.single('imagen') intercepta el campo 'imagen' del formulario antes de pasar al controlador
router.post('/crear', upload.single('imagen'), ReporteController.crear);
router.post('/cambiar-estado', ReporteController.cambiarEstado);

module.exports = router;