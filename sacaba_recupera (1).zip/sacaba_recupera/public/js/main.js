// Esperamos a que cargue todo el HTML antes de ejecutar el script
document.addEventListener("DOMContentLoaded", () => {
    // Validación rápida en el navegador antes de enviar formularios al servidor
    const forms = document.querySelectorAll("form");
    
    forms.forEach(form => {
        form.addEventListener("submit", (e) => {
            // Si el formulario tiene un campo de contraseña, revisamos que tenga mínimo 6 caracteres
            const pass = form.querySelector("input[type='password']");
            if (pass && pass.value.length < 6) {
                alert("La contraseña debe tener al menos 6 caracteres.");
                e.preventDefault(); // Detiene el envío del formulario
            }
        });
    });
});