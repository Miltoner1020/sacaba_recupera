// Importamos las librerías principales que instalamos con npm
const express = require('express');
const session = require('express-session'); // Para guardar la sesión del usuario logueado
const path = require('path'); // Para manejar rutas de carpetas sin problemas en Windows/Linux
require('dotenv').config(); // Carga las variables secretas del archivo .env

// Traemos nuestros archivos de rutas (donde se definen las URLs)
const authRoutes = require('./src/routes/authRoutes');
const reporteRoutes = require('./src/routes/reporteRoutes');

const app = express();

// Configuramos EJS como motor de vistas para poder meter variables JS dentro del HTML
app.set('view engine', 'ejs');
// Le decimos a Express dónde está nuestra carpeta de vistas
app.set('views', path.join(__dirname, 'src', 'views'));

// Middlewares: funciones que procesan los datos antes de que lleguen a las rutas
app.use(express.urlencoded({ extended: true })); // Permite leer los datos que vienen de los formularios HTML
app.use(express.json()); // Permite leer datos en formato JSON
app.use(express.static(path.join(__dirname, 'public'))); // Hace pública la carpeta 'public' (CSS, JS e imágenes subidas)

// Configuración de las sesiones de usuario (cookies)
app.use(session({
    secret: process.env.SESSION_SECRET || 'secret_default', // Clave para firmar la cookie de sesión
    resave: false, // No vuelve a guardar la sesión si no hubo cambios
    saveUninitialized: false, // No crea sesiones vacías hasta que el usuario inicie sesión
    cookie: { secure: false } // En false porque estamos trabajando en localhost (HTTP, no HTTPS)
}));

// Middleware propio: pasa los datos del usuario logueado a TODAS las vistas automáticamente
// Así podemos usar la variable "user" en el header.ejs o index.ejs sin pasarla ruta por ruta
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next(); // Continúa con la siguiente función o ruta
});

// Conectamos nuestras rutas principales con sus prefijos
app.use('/auth', authRoutes);       // Todo lo de login/registro empieza con /auth
app.use('/reportes', reporteRoutes); // Todo lo de objetos perdidos empieza con /reportes

// Si entran a la raíz (localhost:3000), los mandamos directo al muro de reportes
app.get('/', (req, res) => {
    res.redirect('/reportes');
});

// Levantamos el servidor en el puerto 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});